using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public interface IDamage
{
    void TakeDamage();
}

public interface IExplode
{
    void Explode();
}

public interface IGravityPull
{
    void GravityPull();
}

