using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Crates : MonoBehaviour, IDamage, IGravityPull
{

    public int health;

    public void TakeDamage()
    {
        health -= 1;
    }

    public void GravityPull()
    {
        Rigidbody rig = gameObject.GetComponent<Rigidbody>();
        GameObject obj = GameObject.Find("Player");

        gameObject.transform.LookAt(obj.transform);
        rig.AddForce(Vector3.forward * 7, ForceMode.Impulse);
    }


    public void Update()
    {

        if (health <= 0)
        {
            Destroy(gameObject);
        }

    }

}
 