using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shooting : MonoBehaviour
{
    public GameObject Bullethole_Parent;
    //public GameObject Bullet_FX;

    void Update()
    {
        if(Input.GetMouseButtonDown(0))
        {
            RaycastHit hit;
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

            if(Physics.Raycast(ray, out hit))
            {

                Transform objectHit = hit.transform;

                GameObject hole = Instantiate(Bullethole_Parent, hit.point, Quaternion.identity);
                hole.transform.rotation = Quaternion.FromToRotation(Vector3.up, hit.normal);



                /*
                //Didn't work well, idunno.
                GameObject sparks = Instantiate(Bullet_FX, hit.point, Quaternion.identity);
                sparks.transform.rotation = Quaternion.FromToRotation(Vector3.up, hit.normal);
                ParticleSystem ps = sparks.GetComponent<ParticleSystem>();
                var em = ps.emission;
                em.enabled = true;

                GameObject.Destroy(sparks);
                */

                MonoBehaviour[] mono;
                mono = objectHit.gameObject.GetComponents<MonoBehaviour>();

                foreach (MonoBehaviour item in mono)
                {
                    if (item is IDamage)
                    {
                        IDamage temp = item as IDamage;
                        temp.TakeDamage();
                        return;
                    }

                    if (item is IExplode)
                    {
                        IExplode temp = item as IExplode;
                        temp.Explode();
                        return;
                    }
                }    

                Debug.Log(objectHit.name);

            }
        }

        if (Input.GetMouseButtonDown(1))
        {
            RaycastHit hit;
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            Rigidbody rig;

            if(Physics.Raycast(ray, out hit))
            {
                
      
                Transform objectHit = hit.transform;
                GameObject obj = objectHit.gameObject;


                MonoBehaviour[] mono;
                mono = objectHit.gameObject.GetComponents<MonoBehaviour>();

                foreach (MonoBehaviour item in mono)
                {
                    if (item is IGravityPull)
                    {
                        IGravityPull temp = item as IGravityPull;
                        temp.GravityPull();
                        return;
                    }
                }

               /* rig = obj.GetComponent<Rigidbody>();

                rig.transform.LookAt(gameObject.transform);
                rig.AddRelativeForce(Vector3.forward * 7, ForceMode.Impulse);*/

                



            }
        }
    }

}
