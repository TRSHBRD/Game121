using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AmmoPickup : MonoBehaviour, IExplode, IGravityPull
{

    public ParticleSystem ps;

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {

            Debug.Log("Triggered");
            Destroy(gameObject);

        }
    }


    public void Explode()
    {
        ps.GetComponent<ParticleSystem>();
        ps.Play();
        Destroy(gameObject);
    }

    public void GravityPull()
    {
        Rigidbody rig = gameObject.GetComponent<Rigidbody>();
        GameObject obj = GameObject.Find("Player");

        gameObject.transform.LookAt(obj.transform);
        rig.AddForce(Vector3.forward * 7, ForceMode.Impulse);
    }
}
